package com.test.sample1.tests;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
	  System.out.println("test is running.");
  }
}
